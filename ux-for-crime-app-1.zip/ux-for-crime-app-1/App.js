import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import Constants from 'expo-constants';
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

let customFonts = {
  Titan: require('./assets/TitanOne-Regular.ttf'),
};

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fontsLoaded: false,
    };
  }
  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }

  componentDidMount() {
    this._loadFontsAsync();
  }
  render() {
    if (!this.state.fontsLoaded) {
      return <AppLoading />;
    } else {
    return (
      <View style={styles.container}>
        <Image
          source={require('./assets/1092587.jpg')}
          style={styles.upperImg}
        />
        <TouchableOpacity style={styles.apptitle}>
          <Text style={styles.titleText}>CRIME ALERT APP</Text>
        </TouchableOpacity>
        <View style={styles.appInfo}>
          <TouchableOpacity style={styles.touchable}>
            <Text style={{ fontSize: 17,textAlign:'center' }}>
              Get Crime Info About Your Your Area
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.touchable}>
            <Text style={{ fontSize: 17,textAlign:'center' }}>With SOS Button</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.touchable}>
            <Text style={{ fontSize: 17,textAlign:'center' }}>
              You can easily get and share your coordinates
            </Text>
          </TouchableOpacity>
        </View>
        <View>
          <ScrollView horizontal={true} style={styles.appScreens}>
            <TouchableOpacity style={styles.screen1}>
              <Image
                source={{
                  uri:
                    'https://static.mygov.in/rest/s3fs-public/mygov_144104905611412361.jpg',
                }}
                style={{ width: 100, height: 100, alignSelf: 'center' }}
              />
              <Text style={{ fontFamily: 'Titan', textAlign: 'center' }}>
                Crime In Your Area
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.screen2}>
              <Image
                source={require('./assets/26830437.jpg')}
                style={{ width: 100, height: 100, alignSelf: 'center' }}
              />
              <Text style={{ fontFamily: 'Titan', textAlign: 'center' }}>
                SOS Button
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.screen2}>
              <Image
                source={{
                  uri:
                    'https://www.pinclipart.com/picdir/big/98-987668_gps-clipart.png',
                }}
                style={{ width: 100, height: 100, alignSelf: 'center' }}
              />
              <Text style={{ fontFamily: 'Titan', textAlign: 'center' }}>
                Your Coordinates
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    );
  }
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  upperImg: {
    width: '100%',
    height: '30%',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    alignSelf: 'center',
  },
  apptitle: {
    position: 'absolute',
    resizeMode: 'contain',
    backgroundColor: 'white',
    borderRadius: 30,
    width: 180,
    height: 28,
    marginTop: '30%',
    alignSelf: 'center',
    textAlign: 'center',
    justifyContent: 'center',
    
  },
  titleText: {
    fontFamily: 'Titan',
    fontSize: 17,
    marginLeft:15
  },
  appInfo: {
    flex: 1,
    marginTop: 20,
  },
  appIcon: {
    width: 50,
    height: 60,
    marginTop: 30,
  },
  appText1: {
    position: 'absolute',
    right: 60,
    top: 20,
    fontFamily: 'Titan',
    fontSize: 35,
  },
  appText2: {
    position: 'absolute',
    right: 70,
    top: 60,
    fontFamily: 'Titan',
    fontSize: 35,
  },
  appScreens: {
    flex: 1,
    position: 'absolute',
    bottom: 10,
  },
  screen1: {
    backgroundColor: 'white',
    width: 130,
    height: 130,
    marginLeft: 20,
    justifyContent: 'center',
  },
  screen2: {
    backgroundColor: 'white',
    width: 130,
    height: 130,
    marginLeft: 20,
    justifyContent: 'center',
  },
  touchable: {
    backgroundColor: '#FFE5B4',
    height: 40,
    borderRadius: 30,
    textAlign: 'center',
    justifyContent: 'center',
    marginTop:10,
    alignSelf:'center',
  },
});
